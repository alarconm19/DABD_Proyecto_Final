--Creacion de Divisiones:
INSERT INTO AFDB.dbo.Division
(Nombre)
VALUES('A');

INSERT INTO AFDB.dbo.Division
(Nombre)
VALUES('B');

INSERT INTO AFDB.dbo.Division
(Nombre)
VALUES('C');

--Creacion de Categorías
INSERT INTO AFDB.dbo.Categoria
(Nombre, EdadMaxima, EdadMinima)
VALUES('Maxi', 41, 45);

INSERT INTO AFDB.dbo.Categoria
(Nombre, EdadMaxima, EdadMinima)
VALUES('Súper', 46, 50);

INSERT INTO AFDB.dbo.Categoria
(Nombre, EdadMaxima, EdadMinima)
VALUES('Master', 51, 55);